#ifndef MUSIC_PLAYER_H
#define MUSIC_PLAYER_H
#include <Arduino.h>
#include <Tone.h>

class MusicPlayer {
private:
public:
  MusicPlayer();
  void update();
};

#endif